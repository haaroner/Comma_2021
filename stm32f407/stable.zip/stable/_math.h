//#include "math.h"

//class m_math
//{
//	public:
//		m_math();	
//	int map(int start1, int end1, int start2, int end2, int num);
//	
//	private:
//		int sub;
//};